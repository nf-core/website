#!/usr/env python
"""My script to do some amazing analysis."""

import numpy as np
import matplotlib.pyplot as plt

# Make a plot with example data
x = np.linspace(0, 2 * np.pi, 100)
y = np.sin(x)
plt.plot(x, y)

# Add a title, taken from a file
with open("title.txt") as f:
    title = f.read().strip()
plt.title(title)

# Save the plot
plt.savefig("sin.png")
print("Created sin.png")
