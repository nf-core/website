"""My amazing tool."""

__version__ = "0.1dev0"
